# StaticWebsite
 a simple static website i created.

